<?php require "../layouts/header.php"; ?>
<?php require "../../config/config.php"; ?>

<?php 
        // Check if the admin session is set, and redirect to the login page if it is not set
      if(!isset($_SESSION['adminname'])) {
        header("location: https://localhost/secure/blog/admin-panel/admins/login-admins.php");
      }

        // Generate a CSRF token and store it in a session variable
    if (!isset($_SESSION['csrf_token'])) {
      $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
      }

    if(isset($_POST['submit'])) {
        if($_POST['email'] == '' OR $_POST['password'] == '') {
            echo "<div class='alert alert-danger  text-center  role='alert'>
                  enter data into the inputs
              </div>";
        } else {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $captcha = $_POST['captcha']; 

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
              echo "Email Invalid";
          } elseif (empty($password)) {
              echo "Enter Password";
            } elseif (!preg_match("#.*^(?=.{8,20})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$#", $password)) {
              echo "Password should contain atleast 8 characters, one number, one upper case letter, one lower case letter and one special character";
            } // Verify captcha
            elseif ($captcha != $_SESSION['captcha']) { 
              echo "Invalid captcha";
          } else {

            $login = $conn->query("SELECT * FROM admins WHERE email = '$email'");

            $login->execute();

            $row = $login->FETCH(PDO::FETCH_ASSOC);

            if($login->rowCount() > 0) {

                if(password_verify($row['salt'] . $password, $row['mypassword'])){
                    

                    $_SESSION['adminname'] = $row['adminname'];
                    $_SESSION['admin_id'] = $row['id'];
                  

                    header('location: https://localhost/secure/blog/admin-panel/index.php');
                } else {

                  echo "<div class='alert alert-danger  text-center text-white role='alert'>
                            the email or password is wrong
                        </div>";
                }

              
            } else {

              echo "<div class='alert alert-danger  text-center  role='alert'>
                        the email or password is wrong
                    </div>";
            }
        }
      }
    
  }
    // Generate random captcha
$random_num1 = rand(1, 10);
$random_num2 = rand(1, 10);
$captcha_result = $random_num1 + $random_num2;
$_SESSION['captcha'] = $captcha_result;



?>
<div class="row">
        <div class="col">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title mt-5">Login</h5>
              <form method="POST" class="p-auto" action="login-admins.php">
                  <!-- Email input -->
                  <div class="form-outline mb-4">
                    <input type="text" name="email" id="form2Example1" class="form-control" placeholder="Email" />
                   
                  </div>

                  
                  <!-- Password input -->
                  <div class="form-outline mb-4">
                    <input type="password" name="password" id="form2Example2" placeholder="Password" class="form-control" />
                    
                  </div>

    <!-- Captcha input -->
    <div class="form-outline mb-4">
      <label for="captcha"><?php echo $random_num1 . " + " . $random_num2 . " = "; ?></label>
      <input type="text" name="captcha" id="captcha" class="form-control" required/>
  </div>

                  <!-- Submit button -->
                  <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Login</button>

                 
                </form>

            </div>
       </div>
     </div>
</div>
<?php require "../layouts/footer.php";?>