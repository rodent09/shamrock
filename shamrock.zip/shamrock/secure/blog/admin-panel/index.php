<?php require "layouts/header.php"; ?> <!-- including header for the webpage from header.php file in layouts folder -->
<?php require "../config/config.php"; ?> <!--including config file from config folder to connect to the database --> 
<?php 
      // Check if the admin session is set, and redirect to the login page if it is not set
      if(!isset($_SESSION['adminname'])) {
        header("location: https://localhost/secure/blog/admin-panel/admins/login-admins.php");
      }

      //count the number of rows in the "admins" table and stores the result in the $admins
      $select_admins = $conn->query("SELECT COUNT(*) AS admins_number FROM admins");
      $select_admins->execute();
      $admins = $select_admins->fetch(PDO::FETCH_OBJ);

      //count the number of rows in the "posts" table and stores the result in the $posts
      $select_posts = $conn->query("SELECT COUNT(*) AS posts_number FROM posts");
      $select_posts->execute();
      $posts = $select_posts->fetch(PDO::FETCH_OBJ);

?>
            
<div class="row">
        <div class="col-md-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Posts</h5>
              <!-- displays the number of posts -->
              <p class="card-text">number of posts: <?php echo $posts->posts_number; ?></p>
             
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Admins</h5>
              <!-- displays the number of admins -->
              <p class="card-text">number of admins: <?php echo $admins->admins_number; ?></p>
              
            </div>
          </div>
        </div>
</div>
  
<?php require "layouts/footer.php"; ?> <!--including footer for the webpage from footer.php file in layouts folder-->
        