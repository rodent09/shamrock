<?php require "../../config/config.php"; ?> <!--including config file from config folder to connect to the database -->


<?php 
    // Check if the admin session is set, and redirect to the login page if it is not set
    if(!isset($_SESSION['adminname'])) {
        header("location: https://localhost/secure/blog/admin-panel/admins/login-admins.php");
    }
    // Check if the 'po_id' parameter is set in the URL
    if(isset($_GET['po_id'])) {
        // Get the post ID from the URL parameter
        $id = $_GET['po_id'];

        // Prepare a SQL statement to delete the post from the database
        $delete = $conn->prepare("DELETE FROM posts WHERE id = :id");

        // Execute the SQL statement with the post ID parameter
        $delete->execute([
                ':id' => $id
        ]);
        
        // Redirect the user to the posts page after deleting the post
        header('location: https://localhost/secure/blog/admin-panel/posts-admins/show-posts.php');

        
    }  else {
        // If the 'po_id' parameter is not set, redirect the user to a 404 error page
        header("location: https://localhost/secure/blog/404.php");
       
    }  

?>