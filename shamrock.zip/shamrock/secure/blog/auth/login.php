<?php require "../include/header.php"; ?>
<?php require "../config/config.php"; ?>

<?php  
//if there is an active user session, redirect URL login path to index page (prevents URL path traversal) 
if(isset($_SESSION['username'])){
  header("location: https://localhost/secure/blog/index.php");
}
// Generate a CSRF token and store it in a session variable
if (!isset($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_POST['submit'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $captcha = $_POST['captcha']; 


        // Email Format is Validated
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo "Email Invalid";
  } elseif (empty($password)) {
      echo "Enter Password";
       // Password Format is Validated
    } elseif (!preg_match("#.*^(?=.{8,20})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$#", $password)) {
      echo "Password should contain atleast 8 characters, one number, one upper case letter, one lower case letter and one special character";
    } elseif ($captcha != $_SESSION['captcha']) { // Verify captcha
      echo "Invalid captcha";
    } else {
      $login = $conn->prepare("SELECT * FROM users WHERE email = :email");
      $login->execute([':email' => $email]);
      $row = $login->fetch(PDO::FETCH_ASSOC);
      if($login->rowCount() > 0) {

          if(password_verify($row['salt'] . $password, $row['mypassword'])){
          $_SESSION['username'] = $row['username'];
          $_SESSION['user_id'] = $row['id'];

          header('location: https://localhost/secure/blog/index.php');
      } else {
          echo "Invalid email or password";
      }
  }
}
}


// Generate random captcha
$random_num1 = rand(1, 10);
$random_num2 = rand(1, 10);
$captcha_result = $random_num1 + $random_num2;
$_SESSION['captcha'] = $captcha_result;


?>

<form method="POST" action="login.php">
  <!-- Email input -->
  <div class="form-outline mb-4">
      <input type="email" name="email" id="form2Example1" class="form-control" placeholder="Email" required/>
  </div>

  <!-- Password input -->
  <div class="form-outline mb-4">
      <input type="password" name="password" id="form2Example2" placeholder="Password" class="form-control" required/>
  </div>

  <!-- Captcha input -->
  <div class="form-outline mb-4">
      <label for="captcha"><?php echo $random_num1 . " + " . $random_num2 . " = "; ?></label>
      <input type="text" name="captcha" id="captcha" class="form-control" required/>
  </div>


  <!-- Submit button -->
  <button type="submit" name="submit" class="btn btn-primary mb-4 text-center">Login</button>

  <!-- Register buttons -->
  <div class="text-center">
      <p>New member? Create an account <a href="register.php">Register</a></p>
  </div>
</form>

<?php require "../include/footer.php";?>