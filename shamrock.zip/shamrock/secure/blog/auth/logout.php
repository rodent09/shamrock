<?php
 // start the session
session_start();

// unset all session variables
session_unset();

// destroy the session
session_destroy();

// redirect to login page after destroying the session
header ("location: https://localhost/secure/blog/index.php");
?>