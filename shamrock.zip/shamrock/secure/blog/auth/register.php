<?php require "../include/header.php"; ?>
<?php require "../config/config.php"; ?>
<?php
 //if there is an active user session, redirect URL login path to index page (prevents URL path traversal) 
if(isset($_SESSION['username'])){
  header("location: https://localhost/secure/blog/index.php");
}
// Generate a CSRF token and store it in a session variable
if (!isset($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_POST['submit'])) {
  $captcha = $_POST['captcha']; 

  //the input feilds are filtered and sanitized 

  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
  $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
  $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
  $captcha = filter_input(INPUT_POST, 'captcha', FILTER_SANITIZE_STRING);
  // Server-side validation
  $errors = [];
  if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Email address is not valid";
  }
  if (empty($username) || strlen($username) < 3) {
    $errors[] = "Username should be atleast 3 characters long";
  }
  if (empty($password) || !preg_match("#.*^(?=.{8,20})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$#", $password)) {
    $errors[] = "Password should contain atleast 8 characters, one number, one upper case letter, one lower case letter and one special character";
}
if ($captcha != $_SESSION['captcha']) { // Verify captcha
  echo "Invalid captcha";
}



  if (empty($errors)) {

      // a salt is generated
      $salt = bin2hex(random_bytes(16));

      // Password is hashed along the salt
      $mypassword = password_hash($salt . $password, PASSWORD_BCRYPT);

      // the salt is also saved along with the password to the database
      $insert = $conn->prepare("INSERT INTO users (email, username, salt, mypassword) VALUES
      (:email, :username, :salt, :mypassword)");

      $insert->execute([
          ':email' => $email,
          ':username' => $username,
          ':salt' => $salt,
          ':mypassword' => $mypassword
      ]);

      header("location: login.php");
    } else {
      foreach ($errors as $error) {
        echo "<p>Error: $error</p>";
      }
  }
}

// Generate random captcha
$random_num1 = rand(1, 10);
$random_num2 = rand(1, 10);
$captcha_result = $random_num1 + $random_num2;
$_SESSION['captcha'] = $captcha_result;


?>

<form method="POST" action="register.php">
  <!-- Email input -->
  <div class="form-outline mb-4">
      <input type="text" name="email" id="form2Example1" class="form-control" placeholder="Email" />
  </div>

  <div class="form-outline mb-4">
      <input type="text" name="username" id="form2Example1" class="form-control" placeholder="Username" />
  </div>

  <!-- Password input -->
  <div class="form-outline mb-4">
      <input type="password" name="password" id="form2Example2" placeholder="Password" class="form-control" />
  </div>

  <!-- Captcha input -->
  <div class="form-outline mb-4">
      <label for="captcha"><?php echo $random_num1 . " + " . $random_num2 . " = "; ?></label>
      <input type="text" name="captcha" id="captcha" class="form-control" required/>
</div>

  <!-- Submit button -->
  <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Register</button>

  <!-- Register buttons -->
  <div class="text-center">
      <p>Already a member? <a href="login.php">Login</a></p>
  </div>
</form>

<?php require "../include/footer.php";?>