<?php
// Set global error handler function
function errorHandler($errno, $errstr, $errfile, $errline) {
    // Log error to file
    error_log("$errstr in $errfile on line $errline");
    // Display user-friendly error message
    echo "Oops! Something went wrong. Please try again later.";
}

// Register global error handler
set_error_handler("errorHandler");

try {        
    //host
    $host = "localhost";

    //dbname  
    $dbname = "cleanblog";

    //user
    $user = "root";

    //password
    $password = "Hbdty@1234";

    $conn = new PDO("mysql:host=$host; dbname=$dbname",$user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Log error to file
    error_log($e->getMessage());
    // Display user-friendly error message
    echo "Oops! Something went wrong. Please try again later.";
}
?>
