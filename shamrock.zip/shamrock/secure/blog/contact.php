<?php require "include/header.php"; ?> <!--including header for the webpage from header.php file in includes folder -->
<?php require "config/config.php"; ?> <!--including config file from config folder to connect to the database -->

        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <p>Want to get in touch?
                            <br>Send an email to xyz@nci.com<br>
                            I will get back to you as soon as possible!</p>
                  
                           
                                    
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
<?php require "include/footer.php";?> <!--including footer for the webpage from footer.php file in includes folder -->        
