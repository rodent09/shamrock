<?php require "../include/header.php"; ?> <!--including header for the webpage from header.php file in includes folder -->
<?php require "../config/config.php"; ?> <!-- including config file from config folder to connect to the database -->

<?php
    //if there is an active user session, redirect URL login path to index page (prevents URL path traversal) 
    if(!isset($_SESSION['username'])){
      header("location: https://localhost/secure/blog/index.php");
    }
    //Check for form submission 
    if(isset($_POST['submit'])){
        // Check if any of the required fields are empty, and display an error message if they are
        if($_POST['title'] == '' OR $_POST['subtitle'] == '' OR $_POST['body'] == '' OR $_FILES['img']['name'] == ''){
          echo "<div class='alert alert-danger  text-center  role='alert'>
          Enter data into the input fields.
                </div>";
        }else{
            // Get the values from the input fields
            $title = $_POST['title'];
            $subtitle = $_POST['subtitle'];
            $body = $_POST['body'];
            $img = $_FILES['img']['name'];
            $user_id = $_SESSION['user_id'];
            $user_name = $_SESSION['username'];
            
            //save the image in images directory
            $dir ='images/' . basename($img);

            // Prepare a statement to insert the values into the posts table
            $insert = $conn->prepare("INSERT INTO posts (title, subtitle, body, img, user_id, user_name) 
            VALUES (:title, :subtitle, :body, :img, :user_id, :user_name)"); 
            
            // Execute the statement with the values
            $insert->execute([
                ':title' => $title,
                ':subtitle' => $subtitle,
                ':body' => $body,
                ':img' => $img,
                ':user_id' => $user_id,
                ':user_name' => $user_name,
            ]);
            
            //move the uploaded image to the images directory
            if(move_uploaded_file($_FILES['img']['tmp_name'], $dir)){
                header('location: https://localhost/secure/blog/index.php');

            }   
        }
    }
?>

            <form method="POST" action="create.php" enctype="multipart/form-data">
              <!-- Title input -->
              <div class="form-outline mb-4">
                <input type="text" name="title" id="form2Example1" class="form-control" placeholder="title" />
               
              </div>

              <!-- Subtitle input -->
              <div class="form-outline mb-4">
                <input type="text" name="subtitle" id="form2Example1" class="form-control" placeholder="subtitle" />
            </div>

              <!-- Body input -->
              <div class="form-outline mb-4">
                <textarea type="text" name="body" id="form2Example1" class="form-control" placeholder="body" rows="8"></textarea>
            </div>

              <!-- Image input -->
             <div class="form-outline mb-4">
                <input type="file" name="img" id="form2Example1" class="form-control" placeholder="image" />
            </div>


              <!-- Submit button -->
              <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">create</button>

          
            </form>


           
       
<?php require "../include/footer.php"; ?> <!--including footer for the webpage from footer.php file in includes folder -->