<?php require "../config/config.php"; ?> <!-- including config file from config folder to connect to the database -->
<?php require "../include/navbar.php"; ?> <!--including navbar for the webpage from navbar.php file in includes folder -->

<?php
    //if there is an active user session, redirect URL login path to index page (prevents URL path traversal) 
    if(!isset($_SESSION['username'])){
        header("location: https://localhost/secure/blog/index.php");
    }
    //GET the posts id to delete
    if(isset($_GET['del_id'])) {
        $id = $_GET['del_id'];

        //select post from database to delete
        $select = $conn->prepare("SELECT * FROM posts WHERE id =:id");
        $select->execute([':id' => $id]);
        $posts = $select->fetch(PDO::FETCH_OBJ);

        //if logged in user is not the owner of the post, redirect to homepage
        if($_SESSION['user_id'] !== $posts->user_id){
            header('location: https://localhost/secure/blog/index.php');

        } else {
            //if logged in user is the owner of the post, delete post from database and remove the associated image
            $img = $posts->img;

            $delete = $conn->prepare("DELETE FROM posts WHERE id = :id");
            $delete->execute([
                ':id' => $id
            ]);
			if ($delete) {
			unlink("images/$img");
			}
        }

        //redirect to homepage after deletion
        header('location: https://localhost/secure/blog/index.php');

    }else {
        //if post id is not set, redirect to 404 page
        header("location: https://localhost/secure/blog/404.php");
       
    }  

?>