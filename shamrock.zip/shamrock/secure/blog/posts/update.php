<?php require "../include/header.php"; ?> <!--including header for the webpage from header.php file in includes folder -->
<?php require "../config/config.php"; ?> <!--including config file from config folder to connect to the database -->

<?php 
    //if there is an active user session, redirect URL login path to index page (prevents URL path traversal) 
    if(!isset($_SESSION['username']) || !isset($_GET['upd_id']) || !is_numeric($_GET['upd_id'])){
        header("location: https://localhost/secure/blog/index.php");
    }
    //GET the posts id to update
    if(isset($_GET['upd_id'])) {
        $id = $_GET['upd_id'];

        //select post from database to update 
        $select = $conn->prepare("SELECT * FROM posts WHERE id = :id");
        $select->bindParam(':id', $id);
        $select->execute();
        $rows = $select->fetch(PDO::FETCH_OBJ);

        //Redirecting to index page if the author is not the current user while updating. 
        if($_SESSION['user_id'] !== $rows->user_id) {
            header('location: https://localhost/secure/blog/index.php');
          
        }
        
        //Check for form submission 
        if(isset($_POST['submit'])) {
            // Check if any of the required fields are empty, and display an error message if they are
            if($_POST['title'] == '' OR $_POST['subtitle'] == '' OR 
            $_POST['body'] == '') {
                echo "<div class='alert alert-danger  text-center  role='alert'>
                        enter data into the inputs
                    </div>";
            } else {
                
                // Delete the image file related to the post from the server.
                unlink("images/" .$rows->img. "");
                
                // Get the updated post details from the form
                $title = $_POST['title'];
                $subtitle = $_POST['subtitle'];
                $body = $_POST['body'];
                $img = $_FILES['img']['name'];

                // Set the directory path to save the new image
                $dir = 'images/' . basename($img);

                // Update the post details in the database
                $update = $conn->prepare("UPDATE posts SET title = :title, subtitle = :subtitle,
                   body = :body, img = :img WHERE id = :id");
                //preventing sql injection
                $update->bindParam(':title' , $title,);
                $update->bindParam(':subtitle', $subtitle);
                $update->bindParam(':body' , $body);
                $update->bindParam(':img' , $img);
                $update->bindParam(':id', $id);
                $update->execute();    
                

                // Move the new image file to the specified directory
                if(move_uploaded_file($_FILES['img']['tmp_name'], $dir)) {
                    header('location: https://localhost/secure/blog/index.php');
                  
                }

                // Redirect to the homepage after update
                header('location: https://localhost/secure/blog/index.php');

            }
    
        }



    } else {
        //if post id is not set, redirect to 404 page
        header("location: https://localhost/secure/blog/404.php");
      
       
    }




?>

            <form method="POST" action="update.php?upd_id=<?php echo htmlspecialchars($id, ENT_QUOTES, 'UTF-8'); ?>" enctype="multipart/form-data">
  
              <div class="form-outline mb-4">
                <input type="text" name="title" value="<?php echo htmlspecialchars($rows->title, ENT_QUOTES, 'UTF-8'); ?>" id="form2Example1" class="form-control" placeholder="title" />
               
              </div>
           
              <div class="form-outline mb-4">
                <input type="text" name="subtitle" value="<?php echo htmlspecialchars($rows->subtitle, ENT_QUOTES, 'UTF-8'); ?>" id="form2Example1" class="form-control" placeholder="subtitle" />
            </div>

            <div class="form-outline mb-4">
                <textarea type="text" name="body" id="form2Example1" class="form-control" placeholder="body" rows="8"><?php echo $rows->body; ?></textarea>
            </div>
            <?php echo "<img src='images/".$rows->img."' width=900px height=300px> "; ?>
              
            <div class="form-outline mb-4">
                <input type="file" name="img" id="form2Example1" class="form-control" placeholder="image" />
            </div>

              <!-- Submit button -->
              <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Update</button>

          
            </form>



 <?php require "../include/footer.php"; ?> <!--including footer for the webpage from footer.php file in includes folder -->        