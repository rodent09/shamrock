<?php require "../layouts/header.php"; ?> <!-- including header for the webpage from header.php file in layouts folder -->
<?php require "../../config/config.php"; ?> <!--including config file from config folder to connect to the database -->

<?php  
    // Check if the submit button has been clicked
    if(isset($_POST['submit'])) {
        
      // Check if any of the required fields are empty, and display an error message if they are
        if($_POST['email'] == '' OR $_POST['adminname'] == '' OR $_POST['password'] == '') {
          echo "<div class='alert alert-danger  text-center  role='alert'>
                  Enter data into the input fields.
                </div>";
        } else {
          // Get the values from the input fields
          $email = $_POST['email'];
          $adminname = $_POST['adminname'];
          $password = $_POST['password'];
          // Prepare a statement to insert the values into the admins table
          $insert  = $conn->prepare("INSERT INTO admins (email, adminname, mypassword) VALUES
          (:email, :adminname, :mypassword)");
          // Execute the statement with the values
          $insert->execute([
            ':email' => $email,
            ':adminname' => $adminname,
            ':mypassword' => $password
          ]);
          // Redirect to the admin panel index page
          header("location: http://localhost/vulnerable/blog/admin-panel/index.php");
        }
      
    }
?>
<div class="row">
        <div class="col">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title mb-5 d-inline">Create Admins</h5>
                <form method="POST" action="create-admins.php">
                    <!-- Email input -->
                    <div class="form-outline mb-4 mt-4">
                      <input type="email" name="email" id="form2Example1" class="form-control" placeholder="email" />
                    
                    </div>

                    <div class="form-outline mb-4">
                      <input type="text" name="adminname" id="form2Example1" class="form-control" placeholder="username" />
                    </div>
                    <div class="form-outline mb-4">
                      <input type="password" name="password" id="form2Example1" class="form-control" placeholder="password" />
                    </div>
                    <!-- Submit button -->
                    <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Create</button>

          
              </form>

            </div>
          </div>
        </div>
</div>

<?php require "../layouts/footer.php"; ?> <!-- including footer for the webpage from footer.php file in layouts folder -->
