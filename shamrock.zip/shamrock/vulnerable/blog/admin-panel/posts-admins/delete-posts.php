<?php require "../../config/config.php"; ?> <!--including config file from config folder to connect to the database -->


<?php 
    // Check if the 'po_id' parameter is set in the URL
    if(isset($_GET['po_id'])) {
        // Get the post ID from the URL parameter
        $id = $_GET['po_id'];

        // Prepare a SQL statement to delete the post from the database
        $delete = $conn->prepare("DELETE FROM posts WHERE id = :id");

        // Execute the SQL statement with the post ID parameter
        $delete->execute([
                ':id' => $id
        ]);
        
        // Redirect the user to the posts page after deleting the post
        header('location: http://localhost/vulnerable/blog/admin-panel/posts-admins/show-posts.php');    
    }  
?>