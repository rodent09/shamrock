<?php require "../include/header.php"; ?> <!--including header for the webpage from header.php file in includes folder -->
<?php require "../config/config.php"; ?> <!-- including config file from config folder to connect to the database -->
<?php 
//Check for form submission 
if(isset($_POST['submit'])) {
    //Check if email and password are not empty
    if($_POST['email'] == '' OR $_POST['password'] == ''){
        echo "<div class='alert alert-danger  text-center  role='alert'>
                  Enter data into the inputs
              </div>";
    } else{
        $email = $_POST['email'];
        $password = $_POST['password'];

        //Prepare and execute the login query
        $login = $conn->prepare("SELECT * FROM users WHERE email = '$email'");
        $login->execute();
        $row = $login->FETCH(PDO::FETCH_ASSOC);
          //Check f the email exists in the database
          if($login->rowCount() > 0) {
            //Verify the password
            if ($_POST['password'] === $row['mypassword']){
                //Set session variables and redirect to index page
                $_SESSION['username'] =$row['username'];
                $_SESSION['user_id'] =$row['id'];

                header('location: http://localhost/vulnerable/blog/index.php');

            }else {

                  echo "<div class='alert alert-danger  text-center role='alert'>
                            the email or password is wrong
                        </div>";
                 }
         }else {

                  echo "<div class='alert alert-danger  text-center role='alert'>
                            the email or password is wrong
                        </div>";
                 }
          
    }

}

?>

               <form method="POST" action="login.php">
                  <!-- Email input -->
                  <div class="form-outline mb-4">
                    <input type="email" name="email" id="form2Example1" class="form-control" placeholder="Email" />
                   
                  </div>

                  
                  <!-- Password input -->
                  <div class="form-outline mb-4">
                    <input type="password" name="password" id="form2Example2" placeholder="Password" class="form-control" />
                    
                  </div>



                  <!-- Submit button -->
                  <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Login</button>

                  <!-- Register buttons -->
                  <div class="text-center">
                    <p>a new member? Create an acount<a href="register.php"> Register</a></p>
                    

                   
                  </div>
                </form>
<?php require "../include/footer.php"; ?>  <!--including footer for the webpage from footer.php file in includes folder -->             
        
