<?php require "../include/header.php"; ?> <!--including header for the webpage from header.php file in includes folder -->
<?php require "../config/config.php"; ?> <!-- including config file from config folder to connect to the database -->
<?php
  //Check for form submission 
 if(isset($_POST['submit'])){
    //Check if email, username and password are not empty
    if($_POST['email'] == '' OR $_POST['username'] == '' OR $_POST['password'] == '') 
    {
      echo "<div class='alert alert-danger  text-center  role='alert'>
                  Enter data into the inputs
              </div>";
    } 
    else
    {
      // Get the values from the input fields
      $email = $_POST['email'];
      $username= $_POST['username'];
      $password =$_POST['password'];

      // Prepare a statement to insert the values into the users table
      $insert = $conn->prepare("INSERT INTO users (email, username, mypassword) VALUES 
      ( :email, :username, :mypassword)"); 

      // Execute the statement with the values
      $insert->execute([
        ':email' => $email,
        ':username' => $username,
        ':mypassword' => $password
      ]);      
    }
    // Redirect to the admin login page
    header("location: login.php");

  }
?>
            <form method="POST" action="register.php">
              <!-- Email input -->
              <div class="form-outline mb-4">
                <input type="email" name="email" id="form2Example1" class="form-control" placeholder="Email" />
               
              </div>

              <!-- Username input -->
              <div class="form-outline mb-4">
                <input type="" name="username" id="form2Example1" class="form-control" placeholder="Username" />
               
              </div>

              <!-- Password input -->
              <div class="form-outline mb-4">
                <input type="password" name="password" id="form2Example2" placeholder="Password" class="form-control" />
                
              </div>

              <!-- Submit button -->
              <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Register</button>

              <!-- Register buttons -->
              <div class="text-center">
                <p>Aleardy a member? <a href="login.php">Login</a></p>
                

               
              </div>
            </form>

<?php require "../include/footer.php"; ?> <!--including footer for the webpage from footer.php file in includes folder --> 
           
       
 