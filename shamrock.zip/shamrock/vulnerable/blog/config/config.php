<?php
    try{        
    //host
    $host = "localhost";

    //dbname  
    $dbname = "cleanblog";

    //user
    $user = "root";

    //password
    $password = "";

    $conn = new PDO("mysql:host=$host; dbname=$dbname",$user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }catch(PDOException $e){
            echo $e->getMessage();
        }
?>