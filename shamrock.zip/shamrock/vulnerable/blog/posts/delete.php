<?php require "../config/config.php"; ?> <!-- including config file from config folder to connect to the database -->
<?php require "../include/navbar.php"; ?> <!--including navbar for the webpage from navbar.php file in includes folder -->

<?php
    //GET the posts id to delete
    if(isset($_GET['del_id'])) {
        $id = $_GET['del_id'];

        //select post from database to delete
        $select = $conn->query("SELECT * FROM posts WHERE id ='$id'");
        $select->execute();
        $posts = $select->fetch(PDO::FETCH_OBJ);

        //if logged in user is the owner of the post, delete post from database and remove the associated image
        unlink("images/" . $posts->img."");

        $delete = $conn->prepare("DELETE FROM posts WHERE id = :id");
        $delete->execute([
            ':id' => $id
        ]);

        //redirect to homepage after deletion
        header('location: http://localhost/vulnerable/blog/index.php');

    }  

?>