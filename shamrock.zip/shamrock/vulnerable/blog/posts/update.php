<?php require "../include/header.php"; ?> <!--including header for the webpage from header.php file in includes folder -->
<?php require "../config/config.php"; ?> <!--including config file from config folder to connect to the database -->

<?php 
    //GET the posts id to update
    if(isset($_GET['upd_id'])) {
        $id = $_GET['upd_id'];

        //select post from database to update 
        $select = $conn->query("SELECT * FROM posts WHERE id = '$id'");
        $select->execute();
        $rows = $select->fetch(PDO::FETCH_OBJ);
        
        //Check for form submission 
        if(isset($_POST['submit'])) {
            // Check if any of the required fields are empty, and display an error message if they are
            if($_POST['title'] == '' OR $_POST['subtitle'] == '' OR 
            $_POST['body'] == '') {
                echo "<div class='alert alert-danger  text-center  role='alert'>
                        enter data into the inputs
                    </div>";
            } else {
                
                // Delete the image file related to the post from the server.
                unlink("images/" .$rows->img. "");
                
                // Get the updated post details from the form
                $title = $_POST['title'];
                $subtitle = $_POST['subtitle'];
                $body = $_POST['body'];
                $img = $_FILES['img']['name'];

                // Set the directory path to save the new image
                $dir = 'images/' . basename($img);

                // Update the post details in the database
                $update = $conn->prepare("UPDATE posts SET title = :title, subtitle = :subtitle,
                   body = :body, img = :img WHERE id = '$id'");
    
                $update->execute([
                    ':title' => $title,
                    ':subtitle' => $subtitle,
                    ':body' => $body,
                    ':img' => $img
                    
                ]);

                // Move the new image file to the specified directory
                if(move_uploaded_file($_FILES['img']['tmp_name'], $dir)) {
                    header('location: http://localhost/vulnerable/blog/index.php');
                  
                }

                // Redirect to the homepage after update
                header('location: http://localhost/vulnerable/blog/index.php');

            }
        }
    }
?>

            <form method="POST" action="update.php?upd_id=<?php echo $id; ?>" enctype="multipart/form-data">
  
              <div class="form-outline mb-4">
                <input type="text" name="title" value="<?php echo $rows->title; ?>" id="form2Example1" class="form-control" placeholder="title" />
               
              </div>
           
              <div class="form-outline mb-4">
                <input type="text" name="subtitle" value="<?php echo $rows->subtitle; ?>" id="form2Example1" class="form-control" placeholder="subtitle" />
            </div>

            <div class="form-outline mb-4">
                <textarea type="text" name="body" id="form2Example1" class="form-control" placeholder="body" rows="8"><?php echo $rows->body; ?></textarea>
            </div>
            <?php echo "<img src='images/".$rows->img."' width=900px height=300px> "; ?>
              
            <div class="form-outline mb-4">
                <input type="file" name="img" id="form2Example1" class="form-control" placeholder="image" />
            </div>

              <!-- Submit button -->
              <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Update</button>

          
            </form>


 <?php require "../include/footer.php"; ?> <!--including footer for the webpage from footer.php file in includes folder -->        