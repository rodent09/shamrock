<?php require "../include/header.php"; ?> <!--including header for the webpage from header.php file in includes folder -->
<?php require "../config/config.php"; ?> <!--including config file from config folder to connect to the database -->


<?php 
    //GET the profile id to update
    if(isset($_GET['prof_id'])) {
        $id = $_GET['prof_id'];

        //select user profile from database to update 
        $select = $conn->query("SELECT * FROM users WHERE id = '$id'");
        $select->execute();
        $rows = $select->fetch(PDO::FETCH_OBJ);

        //Check for form submission
        if(isset($_POST['submit'])) {
            // Check if any of the required fields are empty, and display an error message if they are
            if($_POST['email'] == '' OR $_POST['username'] == '') {
                echo "<div class='alert alert-danger  text-center  role='alert'>
                        enter data into the inputs
                    </div>";
            } else {

                // Get the profile details from the form
                $email = $_POST['email'];
                $username = $_POST['username'];
            
                // Update the profile details in the database
                $update = $conn->prepare("UPDATE users SET email = :email, username = :username
                    WHERE id = '$id'");
    
                $update->execute([
                    ':email' => $email,
                    ':username' => $username,
                   
                    
                ]);

                // Redirect to the current user profile after update
                header('location: http://localhost/vulnerable/blog/users/profile.php?prof_id='.$_SESSION['user_id'].'');
            }
    
        }
    
    }

?>

            <form method="POST" action="profile.php?prof_id=<?php echo $rows->id; ?>" enctype="multipart/form-data">
              <!-- Email input -->
              <div class="form-outline mb-4">
                <input type="email" name="email" value="<?php echo $rows->email; ?>" id="form2Example1" class="form-control" placeholder="email" />
               
              </div>

              <!-- Username Input -->
              <div class="form-outline mb-4">
                <input type="text" name="username" value="<?php echo $rows->username; ?>" id="form2Example1" class="form-control" placeholder="username" />
            </div>

              <!-- Submit button -->
              <button type="submit" name="submit" class="btn btn-primary  mb-4 text-center">Update</button>

            </form>


 <?php require "../include/footer.php"; ?> <!--including footer for the webpage from footer.php file in includes folder -->        